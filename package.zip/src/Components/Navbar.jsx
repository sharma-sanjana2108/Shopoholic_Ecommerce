import React, { useContext } from 'react'
import { Link } from 'react-router-dom'
import newlogo from "../assets/new logo.png"
import ProductContext from '../Context/ProductContext'
import { useDispatch, useSelector } from 'react-redux'
import { logoutUser } from '../features/auth/authSlice'

const Navbar = () => {
  const { cartItems } = useContext(ProductContext)

  const { user } = useSelector((state) => state.auth)

  const dispatch = useDispatch()

  const handleLogout = async () => {
    dispatch(logoutUser())

  }


  return (

      <nav className="navbar navbar-expand-sm top-nav">
        <div className="container-fluid">
          <img className='logo' src={newlogo} alt=""/>
          <Link className="navbar-brand" to={"/"}>SHOPOHOLIC</Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">

            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/"}><i className="bi bi-house-heart-fill me-1"></i>Home</Link>
              </li>
              {/* <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/menswear"}>Mens</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/womenswear"}>Womens</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/jewellery"}>Jewellery</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/electronics"} >Electronics</Link>
              </li> */}
            </ul>

            

            {
              user ? (
                <>

                <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/menswear"}>Mens</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/womenswear"}>Womens</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/jewellery"}>Jewellery</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active mx-2" to={"/electronics"} >Electronics</Link>
              </li>
                </ul>
                <Link to={"/cart"}> <button className="btn btn-md cartbtn"><i className="bi bi-bag-heart me-2"></i>Bag({cartItems.length})</button></Link>
               
                <button className="btn btn-danger btn-md mx-3" onClick={handleLogout}>Logout</button>
                  </>
              ) : (
                <>
                  <Link to={"/register"}> <button className="btn btn-md cartbtn mx-3" >Register</button></Link>

                  <Link to={"/login"}><button className="btn btn-md cartbtn mx-3" >Login</button></Link>

                </>
              )
            }


          </div>

        </div>
      </nav>
      )
}

    

export default Navbar;

